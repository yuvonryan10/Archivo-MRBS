<?php // -*-mode: PHP; coding:utf-8;-*-
namespace MRBS;

$timezone = "Europe/London";
$dbsys = "mysql";
$db_host = "db";
$db_database = "mrbs";
$db_login = "mrbs";
$db_password = "mrbs";
$db_tbl_prefix = "mrbs_";
$db_persist = FALSE;
$messages['es']['unavailable'] = 'Este equipo ya está reservado. Por favor, verifica la disponibilidad.';
