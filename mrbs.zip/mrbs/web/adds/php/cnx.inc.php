<?php
$u   = "campus";       // Usuario
$p   = "sis@l"; // Contraseña
$bdg = "umdi-sisal";   // Base de datos
?>